﻿
using InventoryManagementSystem.Data;
using InventoryManagementSystem.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InventoryManagementSystem.Controllers
{
    public class SupplierController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public SupplierController(
            ApplicationDbContext context,
            IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }




        public async Task<IActionResult> Index(
   string searchString,
   int page = 1)
        {
            int pageSize = 5;

            var suppliers = _context.Suppliers.AsQueryable();

            if (!string.IsNullOrEmpty(searchString))
            {
                suppliers = suppliers.Where(s =>
                    s.Name.Contains(searchString));
            }

            int totalSuppliers = await suppliers.CountAsync();

            int totalPages = (int)Math.Ceiling(
                totalSuppliers / (double)pageSize);

            if (page < 1)
            {
                page = 1;
            }

            if (page > totalPages && totalPages > 0)
            {
                page = totalPages;
            }

            var suppliersList = await suppliers
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = totalPages;
            ViewBag.SearchString = searchString;

            return View(suppliersList);
        }

        // GET: Supplier/Details
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var supplier = await _context.Suppliers
                .FirstOrDefaultAsync(s => s.Id == id);

            if (supplier == null)
            {
                return NotFound();
            }

            return View(supplier);
        }

        // GET: Supplier/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Supplier/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            Supplier supplier,
            IFormFile? image)
        {
            if (ModelState.IsValid)
            {
                if (image != null)
                {
                    string folder = Path.Combine(
                        _environment.WebRootPath,
                        "images",
                        "suppliers"
                    );

                    if (!Directory.Exists(folder))
                    {
                        Directory.CreateDirectory(folder);
                    }

                    string fileName = Guid.NewGuid().ToString()
                        + Path.GetExtension(image.FileName);

                    string filePath = Path.Combine(
                        folder,
                        fileName
                    );

                    using (var stream = new FileStream(
                        filePath,
                        FileMode.Create))
                    {
                        await image.CopyToAsync(stream);
                    }

                    supplier.Image = "/images/suppliers/" + fileName;
                }

                _context.Suppliers.Add(supplier);

                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(supplier);
        }

        // GET: Supplier/Edit
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var supplier = await _context.Suppliers.FindAsync(id);

            if (supplier == null)
            {
                return NotFound();
            }

            return View(supplier);
        }

        // POST: Supplier/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            int id,
            Supplier supplier,
            IFormFile? image)
        {
            if (id != supplier.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var oldSupplier = await _context.Suppliers
                    .AsNoTracking()
                    .FirstOrDefaultAsync(s => s.Id == id);

                if (oldSupplier == null)
                {
                    return NotFound();
                }

                if (image != null)
                {
                    string folder = Path.Combine(
                        _environment.WebRootPath,
                        "images",
                        "suppliers"
                    );

                    if (!Directory.Exists(folder))
                    {
                        Directory.CreateDirectory(folder);
                    }

                    string fileName = Guid.NewGuid().ToString()
                        + Path.GetExtension(image.FileName);

                    string filePath = Path.Combine(
                        folder,
                        fileName
                    );

                    using (var stream = new FileStream(
                        filePath,
                        FileMode.Create))
                    {
                        await image.CopyToAsync(stream);
                    }

                    supplier.Image = "/images/suppliers/" + fileName;

                    if (!string.IsNullOrEmpty(oldSupplier.Image))
                    {
                        string oldImagePath = Path.Combine(
                            _environment.WebRootPath,
                            oldSupplier.Image.TrimStart('/')
                        );

                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }
                }
                else
                {
                    supplier.Image = oldSupplier.Image;
                }

                _context.Suppliers.Update(supplier);

                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(supplier);
        }

        // GET: Supplier/Delete
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var supplier = await _context.Suppliers
                .FirstOrDefaultAsync(s => s.Id == id);

            if (supplier == null)
            {
                return NotFound();
            }

            return View(supplier);
        }

        // POST: Supplier/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var supplier = await _context.Suppliers
                .FindAsync(id);

            if (supplier == null)
            {
                return NotFound();
            }

            if (!string.IsNullOrEmpty(supplier.Image))
            {
                string imagePath = Path.Combine(
                    _environment.WebRootPath,
                    supplier.Image.TrimStart('/')
                );

                if (System.IO.File.Exists(imagePath))
                {
                    System.IO.File.Delete(imagePath);
                }
            }

            _context.Suppliers.Remove(supplier);

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}




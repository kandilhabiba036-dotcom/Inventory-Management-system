﻿using InventoryManagementSystem.Data;
using InventoryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InventoryManagementSystem.Controllers
{
    public class StockTransactionController : Controller
    {
        private readonly ApplicationDbContext _context;
        public StockTransactionController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: StockTransaction/Index
        public async Task<IActionResult> Index(int page = 1)
        {
            int pageSize = 5;

            var transactions = _context.StockTransactions
                .Include(t => t.Product)
                .AsQueryable();

            int totalTransactions = await transactions.CountAsync();

            int totalPages = (int)Math.Ceiling(
                totalTransactions / (double)pageSize);

            if (page < 1)
            {
                page = 1;
            }

            if (page > totalPages && totalPages > 0)
            {
                page = totalPages;
            }

            var transactionsList = await transactions
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = totalPages;

            return View(transactionsList);
        }

        // GET: StockTransaction/Details
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var transaction = await _context.StockTransactions
                .Include(s => s.Product)
                .FirstOrDefaultAsync(s => s.TransactionId == id);
            if (transaction == null)
            {
                return NotFound();
            }
            return View(transaction);
        }

        // GET: StockTransaction/Create
        public IActionResult Create()
        {
            ViewBag.Products = _context.Products.ToList();
            return View();
        }

        // POST: StockTransaction/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(StockTransaction transaction)
        {
            if (ModelState.IsValid)
            {
                var product = await _context.Products
                    .FindAsync(transaction.ProductId);

                if (product == null)
                {
                    return NotFound();
                }
                
                if (transaction.TransactionType == "Stock In")
                {
                    product.Quantity += transaction.Quantity;
                }
                else if (transaction.TransactionType == "Stock Out")
                {
                    if (transaction.Quantity > product.Quantity)
                    {
                        ModelState.AddModelError("Quantity", "Quantity cannot exceed available stock.");

                        ViewBag.Products = _context.Products.ToList();
                        return View(transaction);
                    }

                    product.Quantity -= transaction.Quantity;
                }

                transaction.TransactionDate = DateTime.Now;

                _context.StockTransactions.Add(transaction);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            ViewBag.Products = _context.Products.ToList();

            return View(transaction);
        }

        // GET: StockTransaction/Delete
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var transaction = await _context.StockTransactions
                .Include(s => s.Product)
                .FirstOrDefaultAsync(s => s.TransactionId == id);
            if (transaction == null)
            {
                return NotFound();
            }
            return View(transaction);
        }

        // POST: StockTransaction/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var transaction = await _context.StockTransactions.FindAsync(id);
            if (transaction == null)
            {
                return NotFound();
            }

            _context.StockTransactions.Remove(transaction);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
